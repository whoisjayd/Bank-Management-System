# Bank-Management System 
**Created By Jaydeep Solanki of Class 12**
# Work To Do
`
1: Change The Email And Password in secrets.py. Name of file is case sensitive so make sure you do it correctly.`


# Instructions
1: I have attached instructions in secrets.py to ensure better understanding


2: I also have instructed along with program in [WELCOME FUNCTION](https://github.com/Git-Jaydeep01/Bank-Management/)


Enjoy !! 😉✌
